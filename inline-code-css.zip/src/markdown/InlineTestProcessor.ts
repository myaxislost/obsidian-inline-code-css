// src/markdown/InlineTestProcessor.ts
import type { Plugin } from "obsidian";
import type { CodeBlockCssPluginSettings } from "../settings/settings";

type Match = { prefix: string; clsNames: string[]; value: string };

function splitOnFirstColon(input: string): { left: string; right: string } | null {
  const idx = input.indexOf(":");
  if (idx === -1) return null;
  return {
    left: input.slice(0, idx),
    right: input.slice(idx + 1),
  };
}

function buildPrefixList(
  map: string[]
): Array<{ prefix: string; clsName: string }> {
  // Normalize + drop invalid/empty entries
  const out: Array<{ prefix: string; clsName: string }> = [];

  for (const v of map) {
    const trimmed = (v ?? "").trim();
    if (!trimmed) continue;

    const parts = splitOnFirstColon(trimmed);
    if (!parts) continue;

    const pfx = parts.left.trim();
    const cls = parts.right.trim();

    if (!pfx || !cls) continue;

    out.push({ prefix: `${pfx}:`, clsName: cls });
  }

  return out;
}

function matchPrefix(
  raw: string,
  list: Array<{ prefix: string; clsName: string }>
): Match | null {
  const t = (raw ?? "").trim();
  if (!t) return null;

  const parts = splitOnFirstColon(t);
  if (!parts) return null;

  const prefixKey = `${parts.left.trim()}:`;
  if (prefixKey === ":") return null;

  const clsNames: string[] = [];
  for (const { prefix, clsName } of list) {
    if (prefixKey === prefix) clsNames.push(clsName);
  }

  if (clsNames.length === 0) return null;

  const value = parts.right.trim();
  return { prefix: parts.left.trim(), clsNames, value };
}

export function registerInlineTestProcessor(
  plugin: Plugin,
  getSettings: () => CodeBlockCssPluginSettings
): void {
  plugin.registerMarkdownPostProcessor((el) => {
    const settings = getSettings();
    const map = settings?.prefixClass ?? [];
    const prefixList = buildPrefixList(map);
    if (prefixList.length === 0) return;

    // Reading view: inline code is <code>, fenced code blocks are <pre><code>
    const codeEls = Array.from(el.querySelectorAll("code"));

    for (const codeEl of codeEls) {
      if (codeEl.parentElement?.tagName === "PRE") continue;

      const raw = codeEl.textContent ?? "";
      const match = matchPrefix(raw, prefixList);
      if (!match) continue;

      const span = document.createElement("span");
      span.classList.add("inline-test");
      for (const c of match.clsNames) span.classList.add(c);

      // Keep the same margin tweak you had before
      span.style.setProperty("margin", "0");

      span.textContent = match.value;

      codeEl.replaceWith(span);
    }
  });
}
