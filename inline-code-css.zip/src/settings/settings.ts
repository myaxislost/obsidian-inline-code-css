// settings.ts
export interface CodeBlockCssPluginSettings {
    prefixClass: string[];
  }
  
  export const DEFAULT_SETTINGS: CodeBlockCssPluginSettings = {
    prefixClass: [
      "<:dialogue-left",
      ">:dialogue-right"
    ]
  };
  
  export function normalizeSettings(data: unknown): CodeBlockCssPluginSettings {
    const base: CodeBlockCssPluginSettings = { ...DEFAULT_SETTINGS };
  
    if (!data || typeof data !== "object") return base;
  
    const raw = data as CodeBlockCssPluginSettings
    const list = raw.prefixClass
    if (!list || typeof list !== "object") return base;
  
    const out: string[] = [];
    for (const v of list) {
      if (!v) continue;

      const parts = v.split(':')
      if (parts.length < 2) continue;
      out.push(v)
    }
  
    return { prefixClass: out };
  }
  